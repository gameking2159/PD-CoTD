import json
from pathlib import Path
import re

def find_min_max_from_jsonl(file_paths):
    min_value = float('inf')
    max_value = float('-inf')

    def extract_numbers(text):
        """Helper function to extract all numbers from a string."""
        return [float(num) for num in re.findall(r'-?\d+\.?\d*', text)]

    # Ensure file_paths is a list
    if not isinstance(file_paths, list):
        file_paths = [file_paths]

    for file_path in file_paths:
        # Specify encoding to avoid UnicodeDecodeError
        with open(file_path, 'r', encoding='utf-8') as file:
            for line in file:
                data = json.loads(line.strip())
                # Extract numbers from 'question' and 'answer' fields if they exist
                if 'question' in data:
                    question_numbers = extract_numbers(data['question'])
                    if question_numbers:
                        min_value = min(min_value, *question_numbers)
                        max_value = max(max_value, *question_numbers)
                if 'answer' in data:
                    answer_numbers = extract_numbers(data['answer'])
                    if answer_numbers:
                        min_value = min(min_value, *answer_numbers)
                        max_value = max(max_value, *answer_numbers)

    return min_value, max_value

# Specify the file paths as a list
file_paths = Path("F:/fune-tuning flan T5/dataset math/GSM8K/grade_school_math/data/add-test.jsonl")

# Find the min and max values
min_value, max_value = find_min_max_from_jsonl(file_paths)

print(f"Minimum value: {min_value}")
print(f"Maximum value: {max_value}")