import json
import os
import http.client
from pathlib import Path

conn = http.client.HTTPSConnection("")

def get_api_key():
    return os.getenv("", "")  


def ensure_directory_exists(path):
    path.parent.mkdir(parents=True, exist_ok=True)


def verify_calculation(calculation, api_key):
    try:
        verification_prompt = f"Please verify if the following calculation and reasoning are correct:\n\n{calculation}\n\nAnswer with 'Correct' or 'Incorrect'."
        
        payload = json.dumps({
            "model": "GLM-4-Flash",
            "messages": [
                {"role": "user", "content": verification_prompt}
            ],
            "temperature": ,
            "max_tokens": ,
            "stream": False,
            "web_search": False
        })

        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }

        conn.request("POST", "/v1/chat/completions", payload, headers)
        res = conn.getresponse()
        response_data = json.loads(res.read().decode("utf-8"))


        if 'choices' in response_data and response_data['choices']:
            content = response_data['choices'][0]['message'].get('content', '').strip()
            return content.lower() == "correct"
        else:
            print("API does not return validation results")
            return False

    except json.JSONDecodeError as e:
        print(f"The content returned by the API is not valid JSON.{e}")
    except Exception as e:
        print(f"unknown error {e}")
    return False

# 主函数
def main():
    api_key = get_api_key()

    input_file_path = Path("")
    output_file_path = Path("")

    ensure_directory_exists(output_file_path)

    try:
        with open(output_file_path, "w", encoding="utf-8") as output_file:
            with open(input_file_path, "r", encoding="utf-8") as input_file:
                for line_number, line in enumerate(input_file, start=1):
                    line = line.strip()
                    print(f"Reading line {line_number}: {line}")

                    try:
                        data = json.loads(line)
                        calculation = data.get("calculation", "")

                        if calculation and verify_calculation(calculation, api_key):
                            print(f"Reasoning correctly, write to the line.{data}")
                            output_file.write(json.dumps(data, ensure_ascii=False) + "\n")
                        else:
                            print(f"Reasoning is incorrect, skip the line:{data}")

                    except json.JSONDecodeError as e:
                        print(f"JSON decoding error：{e} content: {line.strip()}")

    except IOError as e:
        print(f"File processing error: {e}")

    print(f"The processed correctly reasoned data has been successfully output to the: {output_file_path}")

if __name__ == "__main__":
    main()
