import pandas as pd

df = pd.read_parquet("")

df.to_json("", orient='records', lines=True)
