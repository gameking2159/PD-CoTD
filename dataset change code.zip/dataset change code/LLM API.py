import json
import os
import http.client
from pathlib import Path

conn = http.client.HTTPSConnection("")

def get_api_key():
    return os.getenv("", "")  # 请替换为实际的API密钥


def ensure_directory_exists(path):
    path.parent.mkdir(parents=True, exist_ok=True)

def load_few_shot_examples(few_shot_file_path):
    examples = []
    try:
        with open(few_shot_file_path, "r", encoding="utf-8") as file:
            for line in file:
                examples.append(json.loads(line.strip()))
    except Exception as e:
        print(f"An error occurred while loading the few-shot example： {e}")
    return examples

def process_line(line, api_key, few_shot_examples):
    try:
        data = json.loads(line)
        prefix_description = data.get("prefix-description", "")
        question = data.get("question", "no problem")


        few_shot_content = "\n".join(
            f"Example {i + 1}: {example['question']} -> {example['calculation']}"
            for i, example in enumerate(few_shot_examples)
        )


        payload = json.dumps({
            "model": "GLM-4-Flash",
            "messages": [
                {"role": "system", "content": prefix_description + "\n" + few_shot_content},
                {"role": "user", "content": f"{question} Let us think it step by step and please generate your reasoning process as exhaustively as possible."}
            ],
            "temperature": ,
            "max_tokens": ,
            "stream": True,
            "web_search": False
        })

        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }


        conn.request("POST", "/v1/chat/completions", payload, headers)
        res = conn.getresponse()


        model_output = ""


        buffer = ""
        while True:
            chunk = res.read(1024).decode("utf-8")
            if not chunk:
                break
            buffer += chunk
            parts = buffer.split("data: ")
            buffer = parts[-1] 
            for part in parts[:-1]:
                if part.strip():
                    try:
                        response_data = json.loads(part)
                        if 'choices' in response_data and response_data['choices']:
                            delta_content = response_data['choices'][0]['delta'].get('content', '')
                            model_output += delta_content
                    except json.JSONDecodeError as e:
                        print(f"The content returned by the API is not valid JSON: {e} content: {part}")


        if model_output:
            output_data = {
                "input": line,  
                "question": question,
                "calculation": model_output.strip()
            }
            return output_data
        else:
            print(f"The API returns null in the question: {question}")

    except json.JSONDecodeError as e:
        print(f"JSON decoding error: {e} content: {line.strip()}")
    except Exception as e:
        print(f"unknown error: {e}")
    return None


def main():
    api_key = get_api_key()

    input_file_path = Path("")
    output_file_path = Path("")
    few_shot_file_path = Path("")

    ensure_directory_exists(output_file_path)


    few_shot_examples = load_few_shot_examples(few_shot_file_path)

    try:

        with open(output_file_path, "w", encoding="utf-8") as output_file:
            with open(input_file_path, "r", encoding="utf-8") as input_file:
                for line_number, line in enumerate(input_file, start=1):
                    line = line.strip()
                    print(f"Reading line {line_number}: {line}")

                    output_data = process_line(line, api_key, few_shot_examples)
                    if output_data:
                        print(f"write data: {output_data}")
                        try:
  
                            output_file.write(json.dumps(output_data, ensure_ascii=False) + "\n")
                        except Exception as e:
                            print(f"write error: {e}")

    except IOError as e:
        print(f"File processing error: {e}")

    print(f"The processed dataset has been successfully exported to the: {output_file_path}")

if __name__ == "__main__":
    main()