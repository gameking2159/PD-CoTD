import json

def json_to_jsonl(input_json_file, output_jsonl_file):
    try:
        with open(input_json_file, 'r', encoding='utf-8') as json_file:
            data = json.load(json_file)

        if not isinstance(data, list):
            raise ValueError("The content of the input JSON file must be a list.")

        with open(output_jsonl_file, 'w', encoding='utf-8') as jsonl_file:
            for item in data:
                jsonl_file.write(json.dumps(item) + '\n')

        print(f"The conversion was successful:{output_jsonl_file}")
    except Exception as e:
        print(f"error occurred:{e}")

input_json = ''  
output_jsonl = '' 
json_to_jsonl(input_json, output_jsonl)
